const express = require('express'),
      app = express();
const http = require('http'),
      server = http.createServer(app);
const { Server } = require("socket.io"),
      io = new Server(server);

app.use(express.static(__dirname + '/public'));
// ../
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/templates/index.html');
});



// listen for requests
server.listen(3000, () => {
  console.log('listening on *:3000');
});
